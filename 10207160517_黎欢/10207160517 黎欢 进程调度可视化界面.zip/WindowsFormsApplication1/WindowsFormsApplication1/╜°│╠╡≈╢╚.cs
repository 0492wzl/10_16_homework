﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace WindowsFormsApplication1
{
    public partial class 进程调度 : Form
    {
        public 进程调度()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Pen p = new Pen(Color.Black, 3);
            g.DrawLine(p, 80,30, 80,350);
            g.DrawLine(p, 80, 350, 900,350);
            AdjustableArrowCap arrow = new AdjustableArrowCap(8, 10, true);
            AdjustableArrowCap arrow2 = new AdjustableArrowCap(8, 10, false);
            p.CustomEndCap = arrow;
            Pen p4 = new Pen(Color.Black, 3);
            for (int i = 0; i <= 45; i++)
                g.DrawLine(p4, 80 + i * 18, 350, 80 + i * 18, 345);
            Pen p1 = new Pen(Color.Blue, 5);
            g.DrawLine(p1, 80, 60,(int.Parse(textBox1.Text))*18+80, 60);
            Pen p2 = new Pen(Color.Red, 5);
            g.DrawLine(p2, (int.Parse(textBox1.Text))*18 + 80, 160, (int.Parse(textBox2.Text))*18 + (int.Parse(textBox1.Text))*18 + 80, 160);
            Pen p3 = new Pen(Color.Yellow, 5);
            g.DrawLine(p3, (int.Parse(textBox2.Text))*18 + (int.Parse(textBox1.Text))*18 + 80, 260, (int.Parse(textBox3.Text))*18 +( int.Parse(textBox2.Text))*18 + (int.Parse(textBox1.Text))*18 + 80, 260);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       

        
        
    }
}
